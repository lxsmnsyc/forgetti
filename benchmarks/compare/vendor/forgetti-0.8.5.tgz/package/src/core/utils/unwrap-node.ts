import type * as t from '@babel/types';
import { isNestedExpression } from './checks';

type TrueTypeFilter<U extends t.Node> = (node: t.Node) => node is U;

type TypeCheck<K> = K extends TrueTypeFilter<infer U> ? U : never;

type TypeFilter = (node: t.Node) => boolean;

export default function unwrapNode<K extends TypeFilter>(
  node: t.Node,
  key: K,
): TypeCheck<K> | undefined {
  if (key(node)) {
    return node as TypeCheck<K>;
  }
  if (isNestedExpression(node)) {
    return unwrapNode(node.expression, key);
  }
  return undefined;
}
